/*
 * psddeveloper v3.1.1 
 * Copyright 2015-2016 psdesign 
 * Licensed under MIT psdesign
 */

/*------------------------------------------*/
  $(document).ready(function(e) {
       
	    $('a').on('dragstart', function(event) { event.preventDefault(); });
		$('img').on('dragstart', function(event) { event.preventDefault(); });
		  
	   multifunctionrun()
	   bottomarrow();
	   lb_close();
	   login_sighnup_showhide();
	   leftmenu();
	   
	  
	  
  });
  
  /*--------------------------------------------------*/
  $(window).resize(function(e) {
         multifunctionrun()
	
  });
  /*----------------------------------------------------------*/
  $(window).scroll(function() {
			if($(this).scrollTop() != 0) {$('#back-to-top').fadeIn();}
				 else {$('#back-to-top').fadeOut();}
  });
/*------------------------------------------------------*/
 			
  function multifunctionrun()
  {   // window.alert('testing calling');
	   minheightcontaint();
	   heightresponsive(); 
  }
  
 
 function lb_mycartopen()
 {          $('.ltbxbackground').fadeIn('fast');
	        $('.lightbox_mycart').fadeIn('fast');
	        $('body,html').animate({scrollTop:0},600);
 }
 function lb_loginopen()
 { 
	 $('.ltbxbackground').fadeIn('fast');
	        $('.lightbox_login').fadeIn('fast');
	        $('body,html').animate({scrollTop:0},600);
			       
 }
 function login_sighnup_showhide()
 {           
             $('#lb_title_lginout').html("sign in");
	          $('.logoptcl').click(function(){
			    $('.signuplb').css({"display":"none"});
				$('.forgoutpsslb').css({"display":"none"});
				$('.loginlb').css({"display":"block"});
				$('#lb_title_lginout').html("sign in");
				
             });
			 $('.signoptcl').click(function(){
			     $('.loginlb').css({"display":"none"});
				 $('.forgoutpsslb').css({"display":"none"});
				 $('.signuplb').css({"display":"block"});
				 $('#lb_title_lginout').html("sign up");
             }); 
			  $('.forgotpassa').click(function(){
			     $('.loginlb').css({"display":"none"});
				 $('.signuplb').css({"display":"none"});
				$('.forgoutpsslb').css({"display":"block"});
				$('#lb_title_lginout').html("forgot password");
             }); 
 }
 function lb_close()
 {
	 $('.ltbxclose,.ltbxbackground').click(function(){
			   //window.alert('calling');
			    $('.ltbxbackground').fadeOut('fast');
				$('.lightbox_mycart').fadeOut('fast');
                $('.lightbox_login').fadeOut('fast');			
			});
			 
 }
   function leftmenu()
 {  
    $('#cssmenu li.active').addClass('open').children('ul').show();
	$('#cssmenu li.has-sub>a').on('click', function(){
		$(this).removeAttr('href');
		var element = $(this).parent('li');
		if (element.hasClass('open')) {
			element.removeClass('open');
			element.find('li').removeClass('open');
			element.find('ul').slideUp(200);
		}
		else {
			element.addClass('open');
			element.children('ul').slideDown(200);
			element.siblings('li').children('ul').slideUp(200);
			element.siblings('li').removeClass('open');
			element.siblings('li').find('li').removeClass('open');
			element.siblings('li').find('ul').slideUp(200);
		}
	});
 }
  
  function heightresponsive()
  {  
      // window.alert('calling box height')
	 
	 	var wwidth=$(window).width();
	   if(wwidth>499)
	    {  //window.alert('heigth responsive call');
	      var height100=$('.height_100per').width();  
	              $('.height_100per').height(height100);
		  var height75=$('.height_75per').width(); 
	              $('.height_75per').height(height75/1.5);
		}
	   else
	   {
		   $('.height_100per').height('auto');
	   }
	/*/ 
	 var height125=$('.height_100per').width();  
	              $('.height_100per').height(fulheight1);
   			  
	 var height75=$('.height_75per').width(); 
	              $('.height_75per').height(height75/1.5);
	
	 var height50=$('.height_50per').width(); 
	              $('.height_50per').height(height50/2);
				  
	 var height25=$('.height_25per').width(); 
                 $('.height_25per').height((height25/2)/2);			  			  			  
   */
  
  }
  
  function minheightcontaint()
  {   //alert('calling footer set')
       var wheight=$(window).height(); //window.alert('wind he='+wheight);
	   var hedheight=$('header').height(); //window.alert('header he='+hedheight);
	   var fotheight=$('footer').height(); //window.alert('footer he='+fotheight);
	   var cphert1=wheight-hedheight-fotheight; //window.alert('set  he='+cphert1);
	   $('.container_inner').css({"min-height":cphert1});
  }
  /* document.addEventListener("contextmenu", function(e){ e.preventDefault();}, false);	*/
   function bottomarrow()
   {        $('#back-to-top').click(function() {
				$('body,html').animate({scrollTop:0},600);
			});	
   }
  
   
			 
  
  









